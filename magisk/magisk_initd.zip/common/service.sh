#!/system/bin/sh
# Simple init.d enabler by RXSMB Team - @korom42
# Init.d support

INITPATH=system/etc/init.d
mount -o rw,remount /system
mount -o rw,remount /system /system
if [ ! -d $INITPATH ] ; then
    mkdir $INITPATH
fi
chown 0:0 $INITPATH
chmod 755 $INITPATH
chown 0:0 $INITPATH/*
chmod 755 $INITPATH/*
busybox run-parts $INITPATH
umount /system
